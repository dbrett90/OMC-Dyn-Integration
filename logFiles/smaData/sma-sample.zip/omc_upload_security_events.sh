#!/bin/bash
#
#
#  Description: 	Script to perform upload of security events logs to OMC using Rest API Call.
#					Three (3) log files covering the following threats types will be uploaded:
#						- Target Account Attack (linux_ta_attack.log)
#						- Multiple Failed Login Attack (linux_mfl_attack.log)
#						- Brute Force Attack Attack (linux_bfa_attack.log)
#  Pre-requisite: 	Requires the following 3 environment variables set and OMC
#                   user's password provided at runtime when prompted.
#                   	- tenantID      #Tenant ID. e.g acmeinc
#                   	- instanceName  #OMC Service ID. e.g ops
#                   	- username      #OMC Username. e.g John.Doe@gmail.com
#
#  AUTHOR(S)
#  -------
#  Rene Fontcha, Oracle North America Sales - Cloud Platforms/Security & Management
#
#  MODIFIED        Date                 Comments
#  --------        ----------           -----------------------------------
#  Rene Fontcha    12/22/2017           Initial Creation
#
################################################################################
#

if [[ -z "$tenantID""$username""$instanceName" ]]
   then
	echo "...................................................................................................................."
    echo "Missing required environment variables. Please set tenantID, username, and instanceName environment variables and retry"
	echo "...................................................................................................................."
    exit 10
fi

read -s -p "Please enter your OMC Password:" omc_passwd
echo ""
echo "*********"

if [[ -z "$omc_passwd" ]]
  then
	echo "............................................................................"
	echo "Cannot proceed without a password. Please get your password ready and retry"
	echo "............................................................................"
	exit 11
fi

dts_ext=`date '+%y%m%d_%H%M%S'`

echo "(1) Uploading Target Account Attack Security Log events to OMC Service Instance ${instanceName} in Oracle Cloud Identity Domain ${tenantID}"
echo "    =========================================================================================================================================="

curl -s -k -u ${tenantID}.${username}:${omc_passwd} -X POST -H X-USER-IDENTITY-DOMAIN-NAME:${tenantID} -H X-USR-SERVICE-NAME:${instanceName} --form 'data=@linux_ta_attack.log' "https://${instanceName}-${tenantID}.loganalytics.management.us2.oraclecloud.com/serviceapi/logan.uploads?uploadName=csd_target_attack.${dts_ext}&entityName=myhost.acmeinc.com&entityType=Host%20(Linux)&logSourceName=Linux%20Secure%20Logs&createTarget=yes" -H x-remote-user:${tenantID}.${username}| json_reformat

echo "(2) Uploading Multiple Failed Login Attack Security Log events to OMC Service Instance ${instanceName} in Oracle Cloud Identity Domain ${tenantID}"
echo "    ==========================================================================================================================================="

curl -s -k -u ${tenantID}.${username}:${omc_passwd} -X POST -H X-USER-IDENTITY-DOMAIN-NAME:${tenantID} -H X-USR-SERVICE-NAME:${instanceName} --form 'data=@linux_mfl_attack.log' "https://${instanceName}-${tenantID}.loganalytics.management.us2.oraclecloud.com/serviceapi/logan.uploads?uploadName=csd_multi_failed_attack.${dts_ext}&entityName=myhost.acmeinc.com&entityType=Host%20(Linux)&logSourceName=Linux%20Secure%20Logs&createTarget=yes" -H x-remote-user:${tenantID}.${username}| json_reformat

echo "(3) Uploading Brute Force Attack Attack Security Log events to OMC Service Instance ${instanceName} in Oracle Cloud Identity Domain ${tenantID}"
echo "    ==========================================================================================================================================="

curl -s -k -u ${tenantID}.${username}:${omc_passwd} -X POST -H X-USER-IDENTITY-DOMAIN-NAME:${tenantID} -H X-USR-SERVICE-NAME:${instanceName} --form 'data=@linux_bfa_attack.log' "https://${instanceName}-${tenantID}.loganalytics.management.us2.oraclecloud.com/serviceapi/logan.uploads?uploadName=csd_brute_force_attack.${dts_ext}&entityName=myhost.acmeinc.com&entityType=Host%20(Linux)&logSourceName=Linux%20Secure%20Logs&createTarget=yes" -H x-remote-user:${tenantID}.${username}| json_reformat

echo "(4) Verifying Status of last 3 Uploads"
echo "    ===================================="

sleep 15
curl -s -k -u ${tenantID}.${username}:${omc_passwd} -X GET -H X-USER-IDENTITY-DOMAIN-NAME:${tenantID} -H X-USR-SERVICE-NAME:${instanceName} "https://${instanceName}-${tenantID}.loganalytics.management.us2.oraclecloud.com/serviceapi/logan.uploads?limit=3"| json_reformat
