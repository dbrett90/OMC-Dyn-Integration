#!/bin/bash
#
#
#  Description: Script to perform upload of User Context Data to OMC using Rest API Call.
#
#  Pre-requisite: Requires the following 3 environment variables set and OMC
#                 user's password provided at runtime when prompted.
#                 	- tenantID      #Tenant ID. e.g. acmeinc
#                 	- instanceName  #OMC Service Instance Name. e.g. ops
#                	- username      #OMC Username. e.g. John.Doe@gmail.com
#
#  AUTHOR(S)
#  -------
#  Rene Fontcha, Oracle North America Sales - Cloud Platforms/Security & Management
#
#  MODIFIED        Date                 Comments
#  --------        ----------           -----------------------------------
#  Rene Fontcha    12/22/2017           Initial Creation
#
################################################################################
#

if [[ -z "$tenantID""$username""$instanceName" ]]
   then
	echo "...................................................................................................................."
    echo "Missing required environment variables. Please set tenantID, username, and instanceName environment variables and retry"
	echo "...................................................................................................................."
    exit 10
fi

read -s -p "Please enter your OMC Password:" omc_passwd
echo ""
echo "*********"

if [[ -z "$omc_passwd" ]]
  then
	echo "............................................................................"
	echo "Cannot proceed without a password. Please get your password ready and retry"
	echo "............................................................................"
	exit 11
fi
dts_ext=`date '+%Y-%m-%d %H:%M:%S'`

echo "(1) Uploading User Context Data to OMC Service Instance: ${instanceName}, Oracle Cloud Identity Domain: ${tenantID}"
echo "${dts_ext}, ${username},${instanceName},${tenantID}" >> ../log/cloud_days.log
echo "    =============================================================================================================="

curl -s -k -u ${tenantID}.${username}:${omc_passwd} -X POST -H X-USER-IDENTITY-DOMAIN-NAME:${tenantID} -H X-USR-SERVICE-NAME:${instanceName} -H 'Content-Type:application/zip' --data-binary "@gse_users.json.zip" "https://${instanceName}-${tenantID}.management.us2.oraclecloud.com/serviceapi/usermodel.query/upload" -H x-remote-user:${tenantID}.${username}

echo ""
echo "(2) Verifying Upload Results"
echo "    ========================"
curl -X GET -k -u ${tenantID}.${username}:${omc_passwd} -H X-USER-IDENTITY-DOMAIN-NAME:${tenantID} -H X-USR-SERVICE-NAME:${instanceName} -H 'Content-Type:application/json'  "https://${instanceName}-${tenantID}.management.us2.oraclecloud.com/serviceapi/usermodel.query/uploadResults" | json_reformat

#echo "(3) Checking content of User context data"
#echo "    ========================================"

#curl -X GET -k  -u ${tenantID}.${username}:${omc_passwd} -H X-USER-IDENTITY-DOMAIN-NAME::${tenantID} -H X-USR-SERVICE-NAME:${instanceName} -H 'Content-Type:application/json'  "https://${instanceName}-${tenantID}.management.us2.oraclecloud.com/serviceapi/usermodel.query/users" | json_reformat

